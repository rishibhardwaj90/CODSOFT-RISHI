import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import os

# Paths
base_path = "C:\\Users\\Lenovo\\OneDrive\\Desktop\\CodSoft\\TASKS\\TASK_5\\"
output_img_path = base_path + "outputs_task5\\"
dataset_path = base_path + "dataset_task5.csv"
output_csv_path = base_path + "op_task5.csv"

# Ensure output directory exists
os.makedirs(output_img_path, exist_ok=True)

# Load dataset
df = pd.read_csv(dataset_path)

# Features and target
X = df.drop('Class', axis=1)
y = df['Class']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# Model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Evaluation
print(classification_report(y_test, y_pred))

# Save predictions
output_df = X_test.copy()
output_df['Actual'] = y_test.values
output_df['Predicted'] = y_pred
output_df.to_csv(output_csv_path, index=False)
print("Predictions saved successfully !")

# VISUALIZATIONS
sns.set_theme(style='whitegrid')

# 1. Confusion Matrix
cm = confusion_matrix(y_test, y_pred, labels=model.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=model.classes_)
disp.plot(cmap='Blues')
plt.title("Confusion Matrix")
plt.savefig(output_img_path + "confusion_matrix.png")
plt.close()

# 2. Class Distribution
plt.figure(figsize=(6, 4))
sns.countplot(data=df, x='Class', hue='Class', palette='pastel', legend=False)
plt.title("Distribution of Fraud and Non-Fraud Cases")
plt.xlabel("Class (0 = Not Fraud, 1 = Fraud)")
plt.ylabel("Count")
plt.savefig(output_img_path + "class_distribution.png")
plt.close()

# 3. Amount Distribution by Class
plt.figure(figsize=(6, 4))
sns.boxplot(data=df, x='Class', y='Amount', hue='Class', palette='Set2', legend=False)
plt.yscale('log')  # scale to better view outliers
plt.title("Transaction Amount by Class (Log Scale)")
plt.xlabel("Class")
plt.ylabel("Amount (Log Scale)")
plt.savefig(output_img_path + "amount_by_class.png")
plt.close()

print("Visualizations saved successfully !!")