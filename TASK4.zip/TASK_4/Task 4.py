import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import os

# Paths
base_path = "C:\\Users\\Lenovo\\OneDrive\\Desktop\\CodSoft\\TASKS\\TASK_4\\"
output_img_dir = base_path + "outputs_task4\\"
dataset_path = base_path + "dataset_task4.csv"
output_csv = base_path + "op_task4.csv"

# Ensure output directory exists
os.makedirs(output_img_dir, exist_ok=True)

# Load dataset
df = pd.read_csv(dataset_path).dropna()

# Features and target
X = df[['TV']]
y = df['Sales']

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Model
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Evaluation
mse = mean_squared_error(y_test, y_pred)
print("MSE:", mse)

# Save predictions
out_df = X_test.copy()
out_df['Actual']    = y_test.values
out_df['Predicted'] = y_pred
out_df.to_csv(output_csv, index=False)
print("Predictions saved successfully !")

# VISUALIZATIONS
sns.set_theme(style='whitegrid')

# 1. TV Ads vs Sales (scatter + regression line)
plt.figure(figsize=(6, 4))
plt.scatter(X_test, y_test, label='Actual', alpha=0.7)
plt.plot(X_test, y_pred, color='red', label='Predicted')
plt.xlabel('TV Advertisement Budget ($K)')
plt.ylabel('Sales ($K)')
plt.title('TV Ad Spend vs Sales')
plt.legend()
plt.savefig(output_img_dir + "tv_vs_sales.png")
plt.close()

# 2. Sales Distribution
plt.figure(figsize=(6, 4))
sns.histplot(df['Sales'], bins=20, kde=True)
plt.title("Distribution of Sales")
plt.xlabel("Sales ($K)")
plt.ylabel("Frequency")
plt.savefig(output_img_dir + "sales_distribution.png")
plt.close()

# 3. Residuals Distribution
residuals = y_test.values - y_pred
plt.figure(figsize=(6, 4))
sns.histplot(residuals, bins=20, kde=True)
plt.title("Distribution of Residuals")
plt.xlabel("Residual (Actual − Predicted)")
plt.ylabel("Frequency")
plt.savefig(output_img_dir + "residuals_distribution.png")
plt.close()

print("Visualizations saved successfully !!")