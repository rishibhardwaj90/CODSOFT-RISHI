import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay
import os

# Paths
base_path = "C:\\Users\\Lenovo\\OneDrive\\Desktop\\CodSoft\\TASKS\\TASK_1\\"
output_img_path = base_path + "outputs_task1\\"
dataset_path = base_path + "dataset_task1.csv"
output_csv_path = base_path + "op_task1.csv"

# Ensure output directory exists
os.makedirs(output_img_path, exist_ok=True)

# Load data
df = pd.read_csv(dataset_path)

# Preprocess
df = df[['Survived', 'Pclass', 'Sex', 'Age', 'Fare']].dropna()
df['Sex'] = df['Sex'].map({'male': 0, 'female': 1})

# Features and Target
X = df[['Pclass', 'Sex', 'Age', 'Fare']]
y = df['Survived']

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LogisticRegression()
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Accuracy
print("Accuracy:", accuracy_score(y_test, y_pred))

# Save predictions
output_df = X_test.copy()
output_df['Actual'] = y_test.values
output_df['Predicted'] = y_pred
output_df.to_csv(output_csv_path, index=False)
print("Predictions saved successfully!")

# VISUALIZATIONS

sns.set_theme(style='whitegrid')

# 1. Countplot of survivors
plt.figure(figsize=(6, 4))
sns.countplot(data=df, x='Survived', hue='Survived', palette='pastel', legend=False)
plt.title("Survivor Count")
plt.xticks([0, 1], ['Not Survived', 'Survived'])
plt.savefig(output_img_path + "survivor_count.png")
plt.close()

# 2. Survival by gender
plt.figure(figsize=(6, 4))
sns.barplot(data=df, x='Sex', y='Survived', hue='Sex', palette='Set2', legend=False)
plt.title("Survival Rate by Gender")
plt.xticks([0, 1], ['Male', 'Female'])
plt.ylabel("Survival Rate")
plt.savefig(output_img_path + "survival_by_gender.png")
plt.close()

# 3. Age distribution by survival
plt.figure(figsize=(8, 5))
sns.histplot(data=df, x='Age', hue='Survived', kde=True, bins=30, palette='husl')
plt.title("Age Distribution by Survival")
plt.legend(labels=["Not Survived", "Survived"])
plt.savefig(output_img_path + "age_distribution_by_survival.png")
plt.close()

# 4. Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Not Survived", "Survived"])
disp.plot(cmap="Blues")
plt.title("Confusion Matrix")
plt.savefig(output_img_path + "confusion_matrix.png")
plt.close()

print("Visualizations saved successfully !!")