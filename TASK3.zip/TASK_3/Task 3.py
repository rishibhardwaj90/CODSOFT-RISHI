import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import os

# Paths
base_path = "C:\\Users\\Lenovo\\OneDrive\\Desktop\\CodSoft\\TASKS\\TASK_3\\"
output_img_path = base_path + "outputs_task3\\"
dataset_path = base_path + "dataset_task3.csv"
output_csv_path = base_path + "op_task3.csv"

# Ensure output directory exists
os.makedirs(output_img_path, exist_ok=True)

# Load data
df = pd.read_csv(dataset_path)

# Features and target
X = df.drop('species', axis=1)
y = df['species']

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Predict and report
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))

# Save predictions
output_df = X_test.copy()
output_df['Actual'] = y_test.values
output_df['Predicted'] = y_pred
output_df.to_csv(output_csv_path, index=False)
print("Predictions saved successfully !")

# VISUALIZATIONS
sns.set_theme(style='whitegrid')

# 1. Confusion Matrix
cm = confusion_matrix(y_test, y_pred, labels=model.classes_)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=model.classes_)
disp.plot(cmap='Blues')
plt.title("Confusion Matrix")
plt.savefig(output_img_path + "confusion_matrix.png")
plt.close()

# 2. Feature Importance
importances = model.feature_importances_
features = X.columns
plt.figure(figsize=(6, 4))
sns.barplot(x=importances, y=features, hue=features, palette="viridis", legend=False)
plt.title("Feature Importances")
plt.xlabel("Importance Score")
plt.ylabel("Features")
plt.savefig(output_img_path + "feature_importance.png")
plt.close()

# 3. Pairplot of features
sns.pairplot(df, hue='species', palette='husl')
plt.suptitle("Iris Feature Relationships", y=1.02)
plt.savefig(output_img_path + "pairplot.png")
plt.close()

print("Visualizations saved successfully !!")