import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error
import os

# Paths
base_path = "C:\\Users\\Lenovo\\OneDrive\\Desktop\\CodSoft\\TASKS\\TASK_2\\"
output_img_path = base_path + "outputs_task2\\"
dataset_path = base_path + "dataset_task2.csv"
output_csv_path = base_path + "op_task2.csv"

# Ensure output directory exists
os.makedirs(output_img_path, exist_ok=True)

# Load dataset with proper encoding
df = pd.read_csv(dataset_path, encoding='latin1')

# Clean column names
df.columns = df.columns.str.strip().str.replace('\xa0', ' ')

# Select relevant columns
df = df[['Genre', 'Director', 'Rating']].dropna()

# Encode categorical features
le_genre = LabelEncoder()
le_director = LabelEncoder()
df['Genre'] = le_genre.fit_transform(df['Genre'])
df['Director'] = le_director.fit_transform(df['Director'])

# Features and target
X = df[['Genre', 'Director']]
y = df['Rating']

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Evaluation
print("MSE:", mean_squared_error(y_test, y_pred))

# Save predictions
output_df = X_test.copy()
output_df['Actual'] = y_test.values
output_df['Predicted'] = y_pred
output_df.to_csv(output_csv_path, index=False)
print("Predictions saved successfully !")

# VISUALIZATIONS
sns.set_theme(style='whitegrid')

# 1. Rating Distribution
plt.figure(figsize=(6, 4))
sns.histplot(df['Rating'], bins=20, kde=True, color='skyblue')
plt.title("Distribution of Movie Ratings")
plt.xlabel("Rating")
plt.ylabel("Frequency")
plt.savefig(output_img_path + "rating_distribution.png")
plt.close()

# 2. Actual vs Predicted Ratings (sorted)
comparison_df = pd.DataFrame({
    'Actual': y_test.values,
    'Predicted': y_pred
}).sort_values(by='Actual').reset_index(drop=True)

plt.figure(figsize=(10, 5))
plt.plot(comparison_df['Actual'], label='Actual', marker='o')
plt.plot(comparison_df['Predicted'], label='Predicted', marker='x')
plt.title("Actual vs Predicted Movie Ratings")
plt.xlabel("Sample Index (Sorted by Actual)")
plt.ylabel("Rating")
plt.legend()
plt.tight_layout()
plt.savefig(output_img_path + "actual_vs_predicted.png")
plt.close()

# 3. Top 10 Directors by Average Rating
df['Director Name'] = le_director.inverse_transform(df['Director'])
top10 = df.groupby('Director Name')['Rating'].mean().sort_values(ascending=False).head(10)

plt.figure(figsize=(8, 5))
sns.barplot(x=top10.values, y=top10.index, hue=top10.index, palette='viridis', legend=False)
plt.title("Top 10 Directors by Average Rating")
plt.xlabel("Average Rating")
plt.ylabel("Director")
plt.savefig(output_img_path + "top_10_directors.png")
plt.close()

print("Visualizations saved successfully !!")